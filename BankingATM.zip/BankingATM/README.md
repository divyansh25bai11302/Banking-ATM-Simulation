# Banking & ATM Simulation

A command-line Java application that simulates basic banking operations.

## Features

- Create customer accounts
- Deposit money
- Withdraw money
- Check account balance
- Transfer money between accounts
- View transaction history
- List all accounts
- Input validation and custom exception handling

## Java Concepts

- Object-Oriented Programming
- Encapsulation
- ArrayList
- HashMap
- Exception Handling
- Java Scanner
- Date and time API

## Requirements

- Java JDK 17 or higher recommended
- Terminal / Command Prompt
- No GUI or IDE required

## Project Structure

```text
BankingATM/
├── src/
│   ├── Main.java
│   ├── Bank.java
│   ├── BankAccount.java
│   ├── Customer.java
│   ├── Transaction.java
│   └── BankingException.java
└── README.md
```

## Compile and Run

From the project root directory:

### Windows, Linux, or macOS

```bash
javac -d out src/*.java
java -cp out Main
```

## Example Account Flow

1. Create two accounts.
2. Deposit money into the first account.
3. Transfer money to the second account.
4. Check balances.
5. View transaction history.

## Important Note

This is an educational simulation. It does not connect to a real bank and must not be used for real financial transactions or sensitive information.
